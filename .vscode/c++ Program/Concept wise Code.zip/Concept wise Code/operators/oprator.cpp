/**
Author: Urvish Sojitra
Email: 19bmiit036@gmail.com

Execution Guide: To compile and run this program in "Dev C++ idle", press F11.
*/

//Assignment Operators
#include<iostream>
using namespace std;

int main()
{
	int a; 
	a=5;
	//a=a+9;
	//a=a-9;
	//a=a*9;
	//a=a/9;
	//a=a%9;
	//a=a&9;
	//a=a|9;
	//a=a^9;
	//a=a>>4;
	//a=a<<4;
	//a=a~5;
	cout<<a;
	
	 

}
