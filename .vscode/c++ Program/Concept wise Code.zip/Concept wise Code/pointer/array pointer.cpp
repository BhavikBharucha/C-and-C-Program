/**
Author: Urvish Sojitra
Email: 19bmiit036@gmail.com

Execution Guide: To compile and run this program in "Dev C++ idle", press F11.
*/

#include<iostream>
using namespace std;

int main()
{
    int a[10]={1,2,3,4,5,6,7,8,9,10};
     cout << a <<endl;
     cout << a+1 <<endl;
     cout << &a <<endl;
     cout << &a+1 <<endl;
     cout << *a <<endl;
     cout << *a+2<<endl;
     cout << *(a+2)<<endl;
     cout << a[2]<<endl;
     cout << &a[2]<<endl;
     cout << *&a[2]<<endl;
     
     
     
     
}
