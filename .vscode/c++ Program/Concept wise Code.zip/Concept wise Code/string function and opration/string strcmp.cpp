/**
Author: Urvish Sojitra
Email: 19bmiit036@gmail.com

Execution Guide: To compile and run this program in "Dev C++ idle", press F11.
*/

#include<iostream>
#include<string.h>
using namespace std;

int main()
{
	
	char str1[]={"B"};
	char str2[]={"a"};
	//char str2[]={'u','r','\0'};
	
	
	int i=strcmp(str1,str2);
	
	cout<<i;
	

}
