/**
Author: Urvish Sojitra
Email: 19bmiit036@gmail.com

Execution Guide: To compile and run this program in "Dev C++ idle", press F11.
*/

#include<iostream>

using namespace std;

int main()
{
	int a,b;
	
	cout<<"enter a value=";
	cin.operator>>(a);


	cout<<"your value=";
	cout<<a;

	//cout.operator<<("hi");

}
