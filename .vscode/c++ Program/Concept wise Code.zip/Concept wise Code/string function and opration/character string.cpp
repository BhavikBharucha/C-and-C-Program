/**
Author: Urvish Sojitra
Email: 19bmiit036@gmail.com

Execution Guide: To compile and run this program in "Dev C++ idle", press F11.
*/

#include <bits/stdc++.h> 
using namespace std; 
  
int main() 
{ 
    // Initialize 2D array 
    char colour[4][10] = { "Blue", "Red", "Orange", 
                           "Yellow" }; 
  
    // Printing Strings stored in 2D array 
    for (int i = 0; i < 4; i++) 
        cout << colour[i] << "\n"; 
  
    return 0; 
} 
