/**
Author: Urvish Sojitra
Email: 19bmiit036@gmail.com

Execution Guide: To compile and run this program in "Dev C++ idle", press F11.
*/

#include<iostream>

using namespace std;

int main()
{
	
	
	//for(i=1;i<=10;i++)
	{
	int x=0,y=0,i;
	y=	x++;
	
	cout <<x<<endl<<y<<endl;
	}
	
	{
	int x=0,y=0,i;
	y=	++x;
	
	cout <<x<<endl<<y<<endl;
	}
}
